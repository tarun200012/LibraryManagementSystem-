package Library.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import Library.Model.Book;

public class InventoryService {
	private BookManager bookManager;
    private static final Logger logger = Logger.getLogger(InventoryService.class.getName());

    public InventoryService(BookManager bookManager) {
        this.bookManager = bookManager;
    }

    public List<Book> getAvailableBooks() {
        List<Book> available = new ArrayList<>();
        for (Book book : bookManager.getAllBooks()) {
            if (!book.isBorrowed()) {
                available.add(book);
            }
        }
        logger.info("Fetched available books: " + available.size());
        return available;
    }

    public List<Book> getBorrowedBooks() {
        List<Book> borrowed = new ArrayList<>();
        for (Book book : bookManager.getAllBooks()) {
            if (book.isBorrowed()) {
                borrowed.add(book);
            }
        }
        logger.info("Fetched borrowed books: " + borrowed.size());
        return borrowed;
    }

    public int countAvailableBooks() {
        return getAvailableBooks().size();
    }

    public int countBorrowedBooks() {
        return getBorrowedBooks().size();
    }
}
