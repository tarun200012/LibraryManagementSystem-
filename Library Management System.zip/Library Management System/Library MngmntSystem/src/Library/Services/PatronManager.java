package Library.Services;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import Library.Model.Patron;

public class PatronManager {

	private Map<String, Patron> patrons = new HashMap<>();
    private static final Logger logger = Logger.getLogger(PatronManager.class.getName());

    public void addPatron(Patron patron) {
        patrons.put(patron.getPatronId(), patron);
        logger.info("Added patron: " + patron);
    }

    public void updatePatron(String patronId, Patron updatedPatron) {
        patrons.put(patronId, updatedPatron);
        logger.info("Updated patron: " + patronId);
    }

    public Patron getPatron(String patronId) {
        return patrons.get(patronId);
    }
}
