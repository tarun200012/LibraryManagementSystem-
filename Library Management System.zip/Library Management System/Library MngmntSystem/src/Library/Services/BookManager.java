package Library.Services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import Library.Model.Book;

public class BookManager {
	private Map<String, Book> books = new HashMap<>();
    private static final Logger logger = Logger.getLogger(BookManager.class.getName());

    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
        logger.info("Added book: " + book);
    }

    public void updateBook(String isbn, Book updatedBook) {
        books.put(isbn, updatedBook);
        logger.info("Updated book: " + isbn);
    }

    public void removeBook(String isbn) {
        books.remove(isbn);
        logger.info("Removed book: " + isbn);
    }

    public Book searchByISBN(String isbn) {
        return books.get(isbn);
    }

    public List<Book> searchByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (Book book : books.values()) {
            if (book.getTitle().toLowerCase().contains(title.toLowerCase())) {
                result.add(book);
            }
        }
        return result;
    }

    public List<Book> searchByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book book : books.values()) {
            if (book.getAuthor().toLowerCase().contains(author.toLowerCase())) {
                result.add(book);
            }
        }
        return result;
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }
}
