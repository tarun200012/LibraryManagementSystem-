package Library.Services;
import java.util.logging.Logger;

import Library.Model.Book;
import Library.Model.Patron;

public class LendingService {
	private BookManager bookManager;
    private PatronManager patronManager;
    private static final Logger logger = Logger.getLogger(LendingService.class.getName());

    public LendingService(BookManager bookManager, PatronManager patronManager) {
        this.bookManager = bookManager;
        this.patronManager = patronManager;
    }

    public void checkoutBook(String isbn, String patronId) {
        Book book = bookManager.searchByISBN(isbn);
        Patron patron = patronManager.getPatron(patronId);
        if (book != null && patron != null && !book.isBorrowed()) {
            book.setBorrowed(true);
            patron.addBookToHistory(book);
            logger.info("Book checked out: " + book + " to " + patron);
        } else {
            logger.warning("Checkout failed for ISBN: " + isbn);
        }
    }

    public void returnBook(String isbn, String patronId) {
        Book book = bookManager.searchByISBN(isbn);
        if (book != null && book.isBorrowed()) {
            book.setBorrowed(false);
            logger.info("Book returned: " + isbn);
        } else {
            logger.warning("Return failed for ISBN: " + isbn);
        }
    }
}
