package Library;

import Library.Model.Book;
import Library.Model.Patron;
import Library.Services.BookManager;
import Library.Services.LendingService;
import Library.Services.PatronManager;
import Library.Services.InventoryService;

import java.util.List;
import java.util.Scanner;

public class LibraryApplication {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookManager bookManager = new BookManager();
        PatronManager patronManager = new PatronManager();
        LendingService lendingService = new LendingService(bookManager, patronManager);
        InventoryService inventoryService = new InventoryService(bookManager);

        while (true) {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Add Book");
            System.out.println("2. Add Patron");
            System.out.println("3. Search Book");
            System.out.println("4. Checkout Book");
            System.out.println("5. Return Book");
            System.out.println("6. View Available Books");
            System.out.println("7. View Borrowed Books");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Enter publication year: ");
                    int year = scanner.nextInt();
                    scanner.nextLine();
                    Book book = new Book(title, author, isbn, year);
                    bookManager.addBook(book);
                    System.out.println("Book added.");
                    break;

                case 2:
                    System.out.print("Enter Patron ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    Patron patron = new Patron(id, name);
                    patronManager.addPatron(patron);
                    System.out.println("Patron added.");
                    break;

                case 3:
                    System.out.print("Search by (1) Title or (2) Author or (3) ISBN? ");
                    int searchChoice = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter search term: ");
                    String query = scanner.nextLine();
                    List<Book> foundBooks;
                    if (searchChoice == 1) {
                        foundBooks = bookManager.searchByTitle(query);
                    } else if (searchChoice == 2) {
                        foundBooks = bookManager.searchByAuthor(query);
                    } else {
                        Book found = bookManager.searchByISBN(query);
                        foundBooks = found != null ? List.of(found) : List.of();
                    }
                    if (foundBooks.isEmpty()) {
                        System.out.println("No books found.");
                    } else {
                        foundBooks.forEach(System.out::println);
                    }
                    break;

                case 4:
                    System.out.print("Enter ISBN to checkout: ");
                    String checkoutIsbn = scanner.nextLine();
                    System.out.print("Enter Patron ID: ");
                    String checkoutId = scanner.nextLine();
                    lendingService.checkoutBook(checkoutIsbn, checkoutId);
                    break;

                case 5:
                    System.out.print("Enter ISBN to return: ");
                    String returnIsbn = scanner.nextLine();
                    System.out.print("Enter Patron ID: ");
                    String returnId = scanner.nextLine();
                    lendingService.returnBook(returnIsbn, returnId);
                    break;

                case 6:
                    System.out.println("Available books:");
                    inventoryService.getAvailableBooks().forEach(System.out::println);
                    break;

                case 7:
                    System.out.println("Borrowed books:");
                    inventoryService.getBorrowedBooks().forEach(System.out::println);
                    break;

                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
