package Library.Model;
import java.util.ArrayList;
import java.util.List;

public class Patron {
	
	 	private String patronId;
	    private String name;
	    private List<Book> borrowingHistory;
	    
	    public Patron(String patronId, String name) {
	        this.patronId = patronId;
	        this.name = name;
	        this.borrowingHistory = new ArrayList<>();
	    }
	    
		public String getPatronId() {
			return patronId;
		}
		public void setPatronId(String patronId) {
			this.patronId = patronId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public List<Book> getBorrowingHistory() {
			return borrowingHistory;
		}
		public void setBorrowingHistory(List<Book> borrowingHistory) {
			this.borrowingHistory = borrowingHistory;
		}  
		
		 public void addBookToHistory(Book book) {
			 borrowingHistory.add(book);
			 }
		  public String toString() {
		        return name + " (ID: " + patronId + ")";
		    }
}
